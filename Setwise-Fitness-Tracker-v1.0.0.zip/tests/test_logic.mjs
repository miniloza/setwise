/*
  Headless regression test for core data flows. Runs with Node 22, no packages required.
  node --experimental-default-type=module tests/test_logic.mjs
*/
import assert from 'node:assert/strict';

let stored=null;
let initialized=false;
class InMemoryDatabase {
  objectStoreNames={contains:(name)=>initialized};
  createObjectStore(){initialized=true;}
  transaction(){
    const tx={oncomplete:null,onerror:null,onabort:null};
    tx.objectStore=()=>({
      get:()=>{const request={result:structuredClone(stored)};setTimeout(()=>tx.oncomplete?.(),0);return request;},
      put:(value)=>{stored=structuredClone(value);const request={result:undefined};setTimeout(()=>tx.oncomplete?.(),0);return request;}
    });
    return tx;
  }
  close(){}
}
const database=new InMemoryDatabase();
globalThis.indexedDB={open:()=>{
  const req={result:database};
  setTimeout(()=>{if(!initialized)req.onupgradeneeded?.();req.onsuccess?.();},0);
  return req;
}};
const handlers={};
const elements={
  app:{_html:'',get innerHTML(){return this._html;},set innerHTML(x){this._html=x;},contains:()=>true,addEventListener:(type,cb)=>handlers[type]=cb},
  toast:{textContent:'',className:''},
  'import-file':{addEventListener:()=>{}}
};
globalThis.document={getElementById:(id)=>elements[id]??null};
globalThis.window={scrollTo:()=>{}};
Object.defineProperty(globalThis,'navigator',{value:{}});
globalThis.location={protocol:'file:'};
globalThis.confirm=()=>true;

const {loadData,writeData,validateData,DB_NAME}=await import('../db.js');
assert.equal(DB_NAME,'setwise-workouts');
assert.equal(validateData({schemaVersion:1,exercises:[],sessions:[],settings:{}}).schemaVersion,1);
const invalid=await loadData();
assert.ok(invalid.exercises.length>30);
await import('../app.js');
await new Promise(r=>setTimeout(r,20));
assert.match(elements.app.innerHTML,/Every rep/);
const click=async (action, params={})=>{
  const target={dataset:{action,...params}};
  await handlers.click({target:{closest:()=>target}});
};
await click('start',{group:'Chest'});
assert.equal(stored.sessions.length,1);
assert.equal(stored.sessions[0].bodyPart,'Chest');
let match=elements.app.innerHTML.match(/data-action="open-exercise" data-id="([^"]+)"/);
assert.ok(match);
const exerciseId=match[1];
await click('open-exercise',{id:exerciseId});
assert.match(elements.app.innerHTML,/PREVIOUS SESSION/);
assert.match(elements.app.innerHTML,/AVERAGE · SET 1/);
const submit=async(next,weight,reps)=>{
  elements['weight-input']={value:String(weight)};
  elements['reps-input']={value:String(reps)};
  await handlers.submit({target:{id:'log-set-form'},submitter:{value:next},preventDefault:()=>{}});
};
await submit('set',60,10);
assert.equal(stored.sessions[0].sets[0].weight,60);
assert.match(elements.app.innerHTML,/SET 01/);
await submit('exercise',55,8);
assert.equal(stored.sessions[0].sets.length,2);
assert.equal(stored.sessions[0].sets[1].setNumber,2);
assert.match(elements.app.innerHTML,/Choose your exercise/);
await click('finish-session');
assert.ok(stored.sessions[0].endedAt);
assert.match(elements.app.innerHTML,/Chest Press Machine/);
await click('nav',{view:'insights'});
assert.match(elements.app.innerHTML,/WEIGHT PROGRESSION/);
assert.match(elements.app.innerHTML,/Maximum weight recorded/);
await click('nav',{view:'session'});
assert.match(elements.app.innerHTML,/Choose a workout/);
const reloaded=await loadData();
assert.equal(reloaded.sessions.length,1);
assert.equal(reloaded.sessions[0].sets.length,2);
assert.equal(reloaded.sessions[0].sets[0].reps,10);
// Invalid restore candidate must not corrupt the database.
const corrupted=structuredClone(reloaded);
corrupted.sessions[0].sets[0].exerciseId='not-present';
assert.throws(()=>validateData(corrupted),/invalid set/);
assert.equal((await loadData()).sessions[0].sets.length,2);
assert.equal(invalid.settings.incrementKg,2.5);
console.log('PASS: IndexedDB read/write, first workout, save two sets, next exercise, finish, history, insights, restart persistence, malformed backup protection.');
